package com.wolfpack.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class WolfPackAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(WolfPackAdminApplication.class, args);
    }
}